<?php 
  class Post {

    private $conn;
    private $table = 'product';

    public $id;
    public $name;
    public $uom;
    public $stock;
    public $price;


    public function __construct($db) {
      $this->conn = $db;
    }

    public function read() {
      // Create query
      $query = 'SELECT * FROM ' . $this->table . ' ORDER BY id';
      
      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    public function read_single() {
          $query = 'SELECT * FROM ' . $this->table . ' WHERE id = ?';

          $stmt = $this->conn->prepare($query);

          $stmt->bindParam(1, $this->id);

          $stmt->execute();

          $row = $stmt->fetch(PDO::FETCH_ASSOC);

          $this->id = $row['Id'];
          $this->name = $row['Name'];
          $this->uom = $row['UOM'];
          $this->stock = $row['Stock'];
          $this->price = $row['Price'];
    }
  }
